# LLM.sh

```
~$: pip install llm-sh
~$: llm rename all files in this directory from snake case to camelcase
```
