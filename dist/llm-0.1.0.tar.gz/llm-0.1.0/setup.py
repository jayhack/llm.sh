# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': '.'}

packages = \
['src']

package_data = \
{'': ['*']}

install_requires = \
['click>=8.1.3,<9.0.0',
 'colorama>=0.4.6,<0.5.0',
 'halo>=0.0.31,<0.0.32',
 'openai>=0.25.0,<0.26.0']

entry_points = \
{'console_scripts': ['llm = src.main:main']}

setup_kwargs = {
    'name': 'llm',
    'version': '0.1.0',
    'description': '',
    'long_description': '# LLM.sh\n\n```\n~$: pip install llm-sh\n~$: llm rename all files in this directory from snake case to camelcase\n```\n',
    'author': 'jayhack',
    'author_email': 'jayhack.0@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
