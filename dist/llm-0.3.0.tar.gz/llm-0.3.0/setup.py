# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': '.'}

packages = \
['src']

package_data = \
{'': ['*']}

install_requires = \
['click>=8.1.3,<9.0.0',
 'colorama>=0.4.6,<0.5.0',
 'halo>=0.0.31,<0.0.32',
 'openai>=0.25.0,<0.26.0',
 'requests==2.28.1']

entry_points = \
{'console_scripts': ['llm = src.main:main']}

setup_kwargs = {
    'name': 'llm',
    'version': '0.3.0',
    'description': '',
    'long_description': '# LLM.sh\n\nCopilot for your command line. Just type `llm XYZ` and it will generate/run a script for you that does XYZ.\n\n# Installation\nInstall bat (https://github.com/sharkdp/bat#installation), a better cat alternative\n```\n~$: port install bat # or brew install bat - \n```\n\n\nInstall LLM.sh via pip\n```\n~$: pip install --upgrade git+https://github.com/jayhack/llm.sh\n```\n\n# Usage\n\nNote that you should expect 10-20s latency for each command.\n\nType `llm [command]`, like so:\n```\n~$: llm rename all files in this directory from snake case to camelcase\n```\n\nYou will receive an output like this:\n```\n───────┬─────────────────────────────────────────────────────────────────────────────────────\n       │ File: temp.sh\n───────┼─────────────────────────────────────────────────────────────────────────────────────\n   1   │ #!/bin/bash\n   2   │\n   3   │ # rename all files in this directory from snake case to camelcase\n   4   │ for file in *; do\n   5   │   mv "$file" "$(echo $file | sed -r \'s/(_)([a-z])/\\U\\2/g\')"\n   6   │ done\n───────┴─────────────────────────────────────────────────────────────────────────────────────\n>> Do you want to run this program? [Y/n]\n```\n\nHit Y (or enter) to run the script. That\'s it!\n',
    'author': 'jayhack',
    'author_email': 'jayhack.0@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
